import Link from "next/link";
import React from "react";

const UsersPage = () => {
  return (
    <main>
      <div>UsersPage</div>
      <Link href="/">Back</Link>
    </main>
  );
};

export default UsersPage;

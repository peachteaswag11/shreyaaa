import Link from "next/link";
import React from "react";

const StudentPage = () => {
  return (
    <main>
      <div>Student</div>
    </main>
  );
};

export default StudentPage;

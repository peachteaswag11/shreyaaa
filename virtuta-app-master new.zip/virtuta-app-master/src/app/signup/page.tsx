import React from 'react'

const SignupPage = () => {
  return (
    <div>
      Signup Page
    </div>
  )
}

export default SignupPage

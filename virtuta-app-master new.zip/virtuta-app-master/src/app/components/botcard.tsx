import React from "react";

const botcard = () => {
  return <div></div>;
};

export default botcard;

import React from 'react'

const NavBar = () => {
  return (
    <div className='flex bg-white'>nav</div>
  )
}

export default NavBar
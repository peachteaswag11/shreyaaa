import Link from "next/link";
import React from "react";

const LoginPage = () => {
  return (
    <main>
      <div>LoginPage</div>
      <Link href="/">Back</Link>
    </main>
  );
};

export default LoginPage;
